# Projeto: Lista de Chamada em C

**Autores:** Matheus Lara, Marlon Andre  
**Curso:** Ciência da Computação  
**Universidade:** Universidade Positivo  

Este programa em C permite gerenciar uma lista de alunos, armazenando nome, idade e média.  
Ele utiliza `realloc()` para expandir dinamicamente o vetor de alunos conforme novos cadastros são inseridos.

### Funcionalidades
- Adicionar alunos dinamicamente
- Exibir lista completa de alunos
- Encerrar o programa com liberação de memória

### Como compilar
```
gcc lista_chamada.c -o lista_chamada
./lista_chamada
```

