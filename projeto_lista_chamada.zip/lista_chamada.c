#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char nome[50];
    int idade;
    float media;
} Aluno;

Aluno* adicionarAluno(Aluno *lista, int *quantidade) {
    lista = realloc(lista, (*quantidade + 1) * sizeof(Aluno));
    if (lista == NULL) {
        printf("Erro ao alocar memoria.\n");
        exit(1);
    }
    printf("Digite o nome do aluno: ");
    scanf(" %49[^
]", lista[*quantidade].nome);
    printf("Digite a idade do aluno: ");
    scanf("%d", &lista[*quantidade].idade);
    printf("Digite a media do aluno: ");
    scanf("%f", &lista[*quantidade].media);
    (*quantidade)++;
    return lista;
}

void exibirAlunos(Aluno *lista, int quantidade) {
    printf("\nLista de alunos:\n");
    for (int i = 0; i < quantidade; i++) {
        printf("%d. Nome: %s | Idade: %d | Media: %.2f\n", i + 1, lista[i].nome, lista[i].idade, lista[i].media);
    }
}

int main() {
    Aluno *lista = NULL;
    int quantidade = 0;
    int opcao;

    do {
        printf("\n1 - Adicionar aluno\n");
        printf("2 - Exibir lista\n");
        printf("0 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                lista = adicionarAluno(lista, &quantidade);
                break;
            case 2:
                exibirAlunos(lista, quantidade);
                break;
            case 0:
                printf("Encerrando...\n");
                break;
            default:
                printf("Opcao invalida.\n");
        }
    } while (opcao != 0);

    free(lista);
    return 0;
}
